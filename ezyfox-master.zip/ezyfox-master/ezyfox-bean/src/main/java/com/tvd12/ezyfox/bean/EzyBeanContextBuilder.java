package com.tvd12.ezyfox.bean;

import com.tvd12.ezyfox.bean.impl.EzyBeanKey;
import com.tvd12.ezyfox.builder.EzyBuilder;
import com.tvd12.ezyfox.properties.EzyPropertiesReader;

import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;

@SuppressWarnings("rawtypes")
public interface EzyBeanContextBuilder extends EzyBuilder<EzyBeanContext> {

    Properties getProperties();

    EzyBeanContextBuilder disableAutoConfiguration();

    EzyBeanContextBuilder scan(String packageName);

    EzyBeanContextBuilder scan(String... packageNames);

    EzyBeanContextBuilder scan(Iterable<String> packageNames);

    EzyBeanContextBuilder scan(Collection<String> packageNames);

    EzyBeanContextBuilder activeProfiles(String activeProfiles);

    EzyBeanContextBuilder excludePackage(String packageName);

    EzyBeanContextBuilder excludePackages(String... packageNames);

    EzyBeanContextBuilder excludePackages(Iterable<String> packageNames);

    EzyBeanContextBuilder addConfigurationClass(Class clazz);

    EzyBeanContextBuilder addConfigurationClasses(Class... classes);

    EzyBeanContextBuilder addConfigurationClasses(Iterable<Class> classes);

    EzyBeanContextBuilder addConfigurationBeforeClass(Class clazz);

    EzyBeanContextBuilder addConfigurationBeforeClasses(Class... classes);

    EzyBeanContextBuilder addConfigurationBeforeClasses(Iterable<Class> classes);

    EzyBeanContextBuilder addConfigurationAfterClass(Class clazz);

    EzyBeanContextBuilder addConfigurationAfterClasses(Class... classes);

    EzyBeanContextBuilder addConfigurationAfterClasses(Iterable<Class> classes);

    EzyBeanContextBuilder addSingleton(Object singleton);

    EzyBeanContextBuilder addSingleton(String name, Object singleton);

    EzyBeanContextBuilder addSingletons(Map<String, Object> singletons);

    EzyBeanContextBuilder addSingletonsByKey(Map<EzyBeanKey, Object> singletons);

    EzyBeanContextBuilder addSingletonClass(Class clazz);

    EzyBeanContextBuilder addSingletonClass(String name, Class clazz);

    EzyBeanContextBuilder addSingletonClasses(Class... classes);

    EzyBeanContextBuilder addSingletonClasses(Iterable<Class> classes);

    EzyBeanContextBuilder addSingletonClasses(Map<String, Class> classes);

    EzyBeanContextBuilder addPrototypeClass(Class clazz);

    EzyBeanContextBuilder addPrototypeClass(String name, Class clazz);

    EzyBeanContextBuilder addPrototypeClasses(Class... classes);

    EzyBeanContextBuilder addPrototypeClasses(Iterable<Class> classes);

    EzyBeanContextBuilder addPrototypeClasses(Map<String, Class> classes);

    EzyBeanContextBuilder addPrototypeSupplier(String objectName, EzyPrototypeSupplier supplier);

    EzyBeanContextBuilder addPrototypeSuppliers(Map<String, EzyPrototypeSupplier> suppliers);

    EzyBeanContextBuilder addAllClasses(Object reflection);

    EzyBeanContextBuilder excludeConfigurationClass(Class clazz);

    EzyBeanContextBuilder excludeConfigurationClasses(Class... classes);

    EzyBeanContextBuilder excludeConfigurationClasses(Iterable<Class> classes);

    EzyBeanContextBuilder errorHandler(EzyErrorHandler handler);

    EzyBeanContextBuilder addProperties(Map properties);

    EzyBeanContextBuilder addProperties(String file);

    EzyBeanContextBuilder addProperties(String file, String activeProfiles);

    EzyBeanContextBuilder addProperties(Iterable<String> files);

    EzyBeanContextBuilder addProperties(Iterable<String> files, String activeProfiles);

    EzyBeanContextBuilder addProperties(File file);

    EzyBeanContextBuilder addProperties(File file, String activeProfiles);

    EzyBeanContextBuilder addProperties(Collection<File> files);

    EzyBeanContextBuilder addProperties(Collection<File> files, String activeProfiles);

    EzyBeanContextBuilder addProperties(InputStream inputStream);

    EzyBeanContextBuilder addProperty(String key, Object value);

    EzyBeanContextBuilder propertiesMap(EzyPropertiesMap propertiesMap);

    EzyBeanContextBuilder propertiesReader(EzyPropertiesReader propertiesReader);

    EzyBeanContextBuilder propertiesBeanClass(String prefix, Class propertiesBeanClass);

}
