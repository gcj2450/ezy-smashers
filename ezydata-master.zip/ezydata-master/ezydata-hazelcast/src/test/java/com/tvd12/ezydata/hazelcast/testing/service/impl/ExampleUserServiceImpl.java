package com.tvd12.ezydata.hazelcast.testing.service.impl;

import com.tvd12.ezydata.hazelcast.service.EzySimpleHazelcastMapService;
import com.tvd12.ezydata.hazelcast.testing.entity.ExampleUser;
import com.tvd12.ezydata.hazelcast.testing.service.ExampleUserService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ExampleUserServiceImpl
    extends EzySimpleHazelcastMapService<String, ExampleUser>
    implements ExampleUserService {

    @Override
    public void saveUser(ExampleUser user) {
        map.set(user.getUsername(), user);
    }

    @Override
    public void saveUser(List<ExampleUser> users) {
        set(users);
        set(new HashMap<>());
    }

    @Override
    public ExampleUser getUser(String username) {
        return map.get(username);
    }

    @Override
    protected String getMapName() {
        return "example_users";
    }

    @Override
    public Map<String, ExampleUser> getUsers(Set<String> usernames) {
        return getMapByIds(usernames);
    }

    @Override
    public void deleteUser(String username) {
        remove(username);
    }

    @Override
    public void deleteAllUser() {
        clear();
    }
}
